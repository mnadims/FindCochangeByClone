ALTER TABLE `cc_conqat` CHANGE `list_cochange` `list_cochange` VARCHAR(10000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;
ALTER TABLE `cc_deckard_2_0` CHANGE `list_cochange` `list_cochange` VARCHAR(10000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;
ALTER TABLE `cc_iclones` CHANGE `list_cochange` `list_cochange` VARCHAR(10000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;
ALTER TABLE `cc_nicad5` CHANGE `list_cochange` `list_cochange` VARCHAR(10000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;
ALTER TABLE `cc_simcad` CHANGE `list_cochange` `list_cochange` VARCHAR(10000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;
ALTER TABLE `cc_simian` CHANGE `list_cochange` `list_cochange` VARCHAR(10000) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL;